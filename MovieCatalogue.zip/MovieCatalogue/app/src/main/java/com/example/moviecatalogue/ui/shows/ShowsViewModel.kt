package com.example.moviecatalogue.ui.shows

import androidx.lifecycle.ViewModel
import com.example.moviecatalogue.data.Film
import com.example.moviecatalogue.utils.DataDummy

class ShowsViewModel : ViewModel() {

    fun getTvShows() : List<Film> = DataDummy.generateDataShows()
}