package com.example.moviecatalogue.ui.detail

import androidx.lifecycle.ViewModel
import com.example.moviecatalogue.utils.DataDummy

class DetailViewModel : ViewModel() {

    fun getFilm(title: String) = DataDummy.getSelectedFilm(title)
}