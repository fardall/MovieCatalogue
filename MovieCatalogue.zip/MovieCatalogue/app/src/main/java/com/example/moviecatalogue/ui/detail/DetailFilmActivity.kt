package com.example.moviecatalogue.ui.detail

import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.moviecatalogue.R
import com.example.moviecatalogue.databinding.ActivityDetailFilmBinding

class DetailFilmActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailFilmBinding
    private lateinit var title: String
    private val viewModel: DetailViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailFilmBinding.inflate(layoutInflater)
        setContentView(binding.root)

        title = intent.getStringExtra(EXTRA_FILM)!!
        val film = viewModel.getFilm(title)!!

        val adapter: ArrayAdapter<String> = ArrayAdapter(this, R.layout.casts, R.id.tv_castName, film.casts
        )

        with(binding) {
            listCasts.adapter = adapter
            tvTitle.text = film.title
            tvStatus.text = film.status
            tvLanguage.text = film.originalLanguage
            tvDescription.text = film.description

            Glide .with(this@DetailFilmActivity)
                .load(film.poster)
                .centerCrop()
                .into(ivPoster)
        }

    }

    companion object {
        const val EXTRA_FILM = "extra_film"
    }
}