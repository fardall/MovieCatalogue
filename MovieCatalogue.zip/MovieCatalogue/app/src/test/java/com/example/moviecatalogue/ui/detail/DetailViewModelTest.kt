package com.example.moviecatalogue.ui.detail

import com.example.moviecatalogue.utils.DataDummy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

class DetailViewModelTest {
    private lateinit var viewModel: DetailViewModel
    private val dummyMovie = DataDummy.generateDataMovies()
    private val dummyShow = DataDummy.generateDataShows()

    @Before
    fun setUp() {
        viewModel = DetailViewModel()
    }

    @Test
    fun getMovie() {
        val movieEntites = viewModel.getFilm(dummyMovie[0].title)
        assertNotNull(movieEntites)
        assertEquals(dummyMovie[0].title, movieEntites?.title)
        assertEquals(dummyMovie[0].status, movieEntites?.status)
        assertEquals(dummyMovie[0].originalLanguage, movieEntites?.originalLanguage)
        assertEquals(dummyMovie[0].description, movieEntites?.description)
        assertEquals(dummyMovie[0].casts, movieEntites?.casts)
        assertEquals(dummyMovie[0].poster, movieEntites?.poster)
    }

    @Test
    fun getShow() {
        val showEntities = viewModel.getFilm(dummyShow[0].title)
        assertNotNull(showEntities)
        assertEquals(dummyShow[0].title, showEntities?.title)
        assertEquals(dummyShow[0].status, showEntities?.status)
        assertEquals(dummyShow[0].originalLanguage, showEntities?.originalLanguage)
        assertEquals(dummyShow[0].description, showEntities?.description)
        assertEquals(dummyShow[0].casts, showEntities?.casts)
        assertEquals(dummyShow[0].poster, showEntities?.poster)
    }
}