package com.example.moviecatalogue.ui.shows

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test

class ShowsViewModelTest {
    private lateinit var viewModel: ShowsViewModel

    @Before
    fun setUp() {
        viewModel = ShowsViewModel()
    }

    @Test
    fun getMovies() {
        val showEntities = viewModel.getTvShows()
        assertNotNull(showEntities)
        assertEquals(10, showEntities.size)
    }
}